## Propensity model to identify potential customers



```python
#importing all the neccessory libraries 
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.compose import make_column_selector as selector
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.model_selection import train_test_split
```


```python
#Loading the training data set
train = pd.read_excel('train.xlsx')
```


```python
#checking the shape
train.shape
```




    (8240, 24)




```python
# Have a look at the data
train.head(30)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>custAge</th>
      <th>profession</th>
      <th>marital</th>
      <th>schooling</th>
      <th>default</th>
      <th>housing</th>
      <th>loan</th>
      <th>contact</th>
      <th>month</th>
      <th>day_of_week</th>
      <th>...</th>
      <th>emp.var.rate</th>
      <th>cons.price.idx</th>
      <th>cons.conf.idx</th>
      <th>euribor3m</th>
      <th>nr.employed</th>
      <th>pmonths</th>
      <th>pastEmail</th>
      <th>responded</th>
      <th>profit</th>
      <th>id</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>34.0</td>
      <td>admin.</td>
      <td>single</td>
      <td>university.degree</td>
      <td>no</td>
      <td>no</td>
      <td>yes</td>
      <td>cellular</td>
      <td>apr</td>
      <td>wed</td>
      <td>...</td>
      <td>-1.8</td>
      <td>93.075</td>
      <td>-47.1</td>
      <td>1.498</td>
      <td>5099.1</td>
      <td>999.0</td>
      <td>0.0</td>
      <td>no</td>
      <td>NaN</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>31.0</td>
      <td>services</td>
      <td>single</td>
      <td>high.school</td>
      <td>no</td>
      <td>no</td>
      <td>no</td>
      <td>cellular</td>
      <td>jul</td>
      <td>thu</td>
      <td>...</td>
      <td>1.4</td>
      <td>93.918</td>
      <td>-42.7</td>
      <td>4.968</td>
      <td>5228.1</td>
      <td>999.0</td>
      <td>0.0</td>
      <td>no</td>
      <td>NaN</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>NaN</td>
      <td>admin.</td>
      <td>single</td>
      <td>high.school</td>
      <td>no</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>jun</td>
      <td>NaN</td>
      <td>...</td>
      <td>1.4</td>
      <td>94.465</td>
      <td>-41.8</td>
      <td>4.961</td>
      <td>5228.1</td>
      <td>999.0</td>
      <td>0.0</td>
      <td>no</td>
      <td>NaN</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>52.0</td>
      <td>admin.</td>
      <td>divorced</td>
      <td>university.degree</td>
      <td>unknown</td>
      <td>yes</td>
      <td>no</td>
      <td>cellular</td>
      <td>jul</td>
      <td>tue</td>
      <td>...</td>
      <td>1.4</td>
      <td>93.918</td>
      <td>-42.7</td>
      <td>4.962</td>
      <td>5228.1</td>
      <td>999.0</td>
      <td>0.0</td>
      <td>no</td>
      <td>NaN</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>39.0</td>
      <td>blue-collar</td>
      <td>single</td>
      <td>NaN</td>
      <td>unknown</td>
      <td>yes</td>
      <td>no</td>
      <td>cellular</td>
      <td>jul</td>
      <td>tue</td>
      <td>...</td>
      <td>1.4</td>
      <td>93.918</td>
      <td>-42.7</td>
      <td>4.961</td>
      <td>5228.1</td>
      <td>999.0</td>
      <td>0.0</td>
      <td>no</td>
      <td>NaN</td>
      <td>5.0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>40.0</td>
      <td>entrepreneur</td>
      <td>married</td>
      <td>NaN</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>jun</td>
      <td>thu</td>
      <td>...</td>
      <td>1.4</td>
      <td>94.465</td>
      <td>-41.8</td>
      <td>4.866</td>
      <td>5228.1</td>
      <td>999.0</td>
      <td>0.0</td>
      <td>no</td>
      <td>NaN</td>
      <td>6.0</td>
    </tr>
    <tr>
      <th>6</th>
      <td>50.0</td>
      <td>technician</td>
      <td>single</td>
      <td>NaN</td>
      <td>no</td>
      <td>no</td>
      <td>no</td>
      <td>cellular</td>
      <td>jul</td>
      <td>tue</td>
      <td>...</td>
      <td>1.4</td>
      <td>93.918</td>
      <td>-42.7</td>
      <td>4.961</td>
      <td>5228.1</td>
      <td>999.0</td>
      <td>0.0</td>
      <td>no</td>
      <td>NaN</td>
      <td>7.0</td>
    </tr>
    <tr>
      <th>7</th>
      <td>41.0</td>
      <td>technician</td>
      <td>married</td>
      <td>professional.course</td>
      <td>no</td>
      <td>no</td>
      <td>no</td>
      <td>cellular</td>
      <td>oct</td>
      <td>thu</td>
      <td>...</td>
      <td>-3.4</td>
      <td>92.431</td>
      <td>-26.9</td>
      <td>0.741</td>
      <td>5017.5</td>
      <td>999.0</td>
      <td>0.0</td>
      <td>no</td>
      <td>NaN</td>
      <td>8.0</td>
    </tr>
    <tr>
      <th>8</th>
      <td>23.0</td>
      <td>blue-collar</td>
      <td>single</td>
      <td>basic.4y</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>jun</td>
      <td>fri</td>
      <td>...</td>
      <td>1.4</td>
      <td>94.465</td>
      <td>-41.8</td>
      <td>4.959</td>
      <td>5228.1</td>
      <td>999.0</td>
      <td>0.0</td>
      <td>no</td>
      <td>NaN</td>
      <td>9.0</td>
    </tr>
    <tr>
      <th>9</th>
      <td>29.0</td>
      <td>technician</td>
      <td>married</td>
      <td>professional.course</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>cellular</td>
      <td>aug</td>
      <td>mon</td>
      <td>...</td>
      <td>1.4</td>
      <td>93.444</td>
      <td>-36.1</td>
      <td>4.965</td>
      <td>5228.1</td>
      <td>999.0</td>
      <td>0.0</td>
      <td>no</td>
      <td>NaN</td>
      <td>10.0</td>
    </tr>
    <tr>
      <th>10</th>
      <td>57.0</td>
      <td>retired</td>
      <td>married</td>
      <td>NaN</td>
      <td>unknown</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>jun</td>
      <td>NaN</td>
      <td>...</td>
      <td>1.4</td>
      <td>94.465</td>
      <td>-41.8</td>
      <td>4.961</td>
      <td>5228.1</td>
      <td>999.0</td>
      <td>0.0</td>
      <td>no</td>
      <td>NaN</td>
      <td>11.0</td>
    </tr>
    <tr>
      <th>11</th>
      <td>33.0</td>
      <td>blue-collar</td>
      <td>married</td>
      <td>unknown</td>
      <td>no</td>
      <td>no</td>
      <td>no</td>
      <td>cellular</td>
      <td>jul</td>
      <td>mon</td>
      <td>...</td>
      <td>1.4</td>
      <td>93.918</td>
      <td>-42.7</td>
      <td>4.960</td>
      <td>5228.1</td>
      <td>999.0</td>
      <td>0.0</td>
      <td>no</td>
      <td>NaN</td>
      <td>12.0</td>
    </tr>
    <tr>
      <th>12</th>
      <td>NaN</td>
      <td>technician</td>
      <td>married</td>
      <td>university.degree</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>oct</td>
      <td>wed</td>
      <td>...</td>
      <td>-1.1</td>
      <td>94.601</td>
      <td>-49.5</td>
      <td>0.985</td>
      <td>4963.6</td>
      <td>999.0</td>
      <td>2.0</td>
      <td>no</td>
      <td>NaN</td>
      <td>13.0</td>
    </tr>
    <tr>
      <th>13</th>
      <td>59.0</td>
      <td>housemaid</td>
      <td>married</td>
      <td>NaN</td>
      <td>unknown</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>jun</td>
      <td>thu</td>
      <td>...</td>
      <td>1.4</td>
      <td>94.465</td>
      <td>-41.8</td>
      <td>4.958</td>
      <td>5228.1</td>
      <td>999.0</td>
      <td>0.0</td>
      <td>no</td>
      <td>NaN</td>
      <td>14.0</td>
    </tr>
    <tr>
      <th>14</th>
      <td>38.0</td>
      <td>technician</td>
      <td>married</td>
      <td>university.degree</td>
      <td>no</td>
      <td>no</td>
      <td>no</td>
      <td>cellular</td>
      <td>may</td>
      <td>fri</td>
      <td>...</td>
      <td>-1.8</td>
      <td>92.893</td>
      <td>-46.2</td>
      <td>1.313</td>
      <td>5099.1</td>
      <td>999.0</td>
      <td>1.0</td>
      <td>no</td>
      <td>NaN</td>
      <td>15.0</td>
    </tr>
    <tr>
      <th>15</th>
      <td>44.0</td>
      <td>blue-collar</td>
      <td>married</td>
      <td>NaN</td>
      <td>no</td>
      <td>yes</td>
      <td>yes</td>
      <td>cellular</td>
      <td>may</td>
      <td>mon</td>
      <td>...</td>
      <td>-1.8</td>
      <td>92.893</td>
      <td>-46.2</td>
      <td>1.299</td>
      <td>5099.1</td>
      <td>999.0</td>
      <td>0.0</td>
      <td>no</td>
      <td>NaN</td>
      <td>16.0</td>
    </tr>
    <tr>
      <th>16</th>
      <td>NaN</td>
      <td>technician</td>
      <td>single</td>
      <td>NaN</td>
      <td>unknown</td>
      <td>yes</td>
      <td>yes</td>
      <td>telephone</td>
      <td>jul</td>
      <td>thu</td>
      <td>...</td>
      <td>1.4</td>
      <td>93.918</td>
      <td>-42.7</td>
      <td>4.966</td>
      <td>5228.1</td>
      <td>999.0</td>
      <td>0.0</td>
      <td>no</td>
      <td>NaN</td>
      <td>17.0</td>
    </tr>
    <tr>
      <th>17</th>
      <td>51.0</td>
      <td>blue-collar</td>
      <td>married</td>
      <td>NaN</td>
      <td>no</td>
      <td>yes</td>
      <td>yes</td>
      <td>telephone</td>
      <td>may</td>
      <td>wed</td>
      <td>...</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.858</td>
      <td>5191.0</td>
      <td>999.0</td>
      <td>0.0</td>
      <td>no</td>
      <td>NaN</td>
      <td>18.0</td>
    </tr>
    <tr>
      <th>18</th>
      <td>NaN</td>
      <td>services</td>
      <td>married</td>
      <td>NaN</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>wed</td>
      <td>...</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.858</td>
      <td>5191.0</td>
      <td>999.0</td>
      <td>0.0</td>
      <td>no</td>
      <td>NaN</td>
      <td>19.0</td>
    </tr>
    <tr>
      <th>19</th>
      <td>37.0</td>
      <td>admin.</td>
      <td>single</td>
      <td>university.degree</td>
      <td>no</td>
      <td>no</td>
      <td>yes</td>
      <td>cellular</td>
      <td>aug</td>
      <td>mon</td>
      <td>...</td>
      <td>1.4</td>
      <td>93.444</td>
      <td>-36.1</td>
      <td>4.965</td>
      <td>5228.1</td>
      <td>999.0</td>
      <td>0.0</td>
      <td>no</td>
      <td>NaN</td>
      <td>20.0</td>
    </tr>
    <tr>
      <th>20</th>
      <td>33.0</td>
      <td>admin.</td>
      <td>married</td>
      <td>high.school</td>
      <td>no</td>
      <td>yes</td>
      <td>yes</td>
      <td>telephone</td>
      <td>may</td>
      <td>thu</td>
      <td>...</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.855</td>
      <td>5191.0</td>
      <td>999.0</td>
      <td>0.0</td>
      <td>no</td>
      <td>NaN</td>
      <td>21.0</td>
    </tr>
    <tr>
      <th>21</th>
      <td>39.0</td>
      <td>blue-collar</td>
      <td>married</td>
      <td>basic.9y</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>cellular</td>
      <td>apr</td>
      <td>wed</td>
      <td>...</td>
      <td>-1.8</td>
      <td>93.075</td>
      <td>-47.1</td>
      <td>1.445</td>
      <td>5099.1</td>
      <td>999.0</td>
      <td>5.0</td>
      <td>no</td>
      <td>NaN</td>
      <td>22.0</td>
    </tr>
    <tr>
      <th>22</th>
      <td>55.0</td>
      <td>services</td>
      <td>married</td>
      <td>high.school</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>cellular</td>
      <td>aug</td>
      <td>NaN</td>
      <td>...</td>
      <td>1.4</td>
      <td>93.444</td>
      <td>-36.1</td>
      <td>4.963</td>
      <td>5228.1</td>
      <td>999.0</td>
      <td>0.0</td>
      <td>no</td>
      <td>NaN</td>
      <td>23.0</td>
    </tr>
    <tr>
      <th>23</th>
      <td>27.0</td>
      <td>services</td>
      <td>single</td>
      <td>professional.course</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>cellular</td>
      <td>jun</td>
      <td>tue</td>
      <td>...</td>
      <td>-2.9</td>
      <td>92.963</td>
      <td>-40.8</td>
      <td>1.262</td>
      <td>5076.2</td>
      <td>999.0</td>
      <td>0.0</td>
      <td>no</td>
      <td>NaN</td>
      <td>24.0</td>
    </tr>
    <tr>
      <th>24</th>
      <td>24.0</td>
      <td>student</td>
      <td>single</td>
      <td>high.school</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>cellular</td>
      <td>may</td>
      <td>tue</td>
      <td>...</td>
      <td>-1.8</td>
      <td>93.876</td>
      <td>-40.0</td>
      <td>0.682</td>
      <td>5008.7</td>
      <td>999.0</td>
      <td>0.0</td>
      <td>no</td>
      <td>NaN</td>
      <td>25.0</td>
    </tr>
    <tr>
      <th>25</th>
      <td>40.0</td>
      <td>services</td>
      <td>divorced</td>
      <td>NaN</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>apr</td>
      <td>fri</td>
      <td>...</td>
      <td>-1.8</td>
      <td>93.075</td>
      <td>-47.1</td>
      <td>1.405</td>
      <td>5099.1</td>
      <td>999.0</td>
      <td>0.0</td>
      <td>no</td>
      <td>NaN</td>
      <td>26.0</td>
    </tr>
    <tr>
      <th>26</th>
      <td>NaN</td>
      <td>unknown</td>
      <td>married</td>
      <td>NaN</td>
      <td>no</td>
      <td>no</td>
      <td>no</td>
      <td>telephone</td>
      <td>jun</td>
      <td>wed</td>
      <td>...</td>
      <td>1.4</td>
      <td>94.465</td>
      <td>-41.8</td>
      <td>4.962</td>
      <td>5228.1</td>
      <td>999.0</td>
      <td>0.0</td>
      <td>no</td>
      <td>NaN</td>
      <td>27.0</td>
    </tr>
    <tr>
      <th>27</th>
      <td>25.0</td>
      <td>technician</td>
      <td>married</td>
      <td>NaN</td>
      <td>no</td>
      <td>no</td>
      <td>no</td>
      <td>cellular</td>
      <td>jul</td>
      <td>thu</td>
      <td>...</td>
      <td>1.4</td>
      <td>93.918</td>
      <td>-42.7</td>
      <td>4.963</td>
      <td>5228.1</td>
      <td>999.0</td>
      <td>0.0</td>
      <td>no</td>
      <td>NaN</td>
      <td>28.0</td>
    </tr>
    <tr>
      <th>28</th>
      <td>35.0</td>
      <td>technician</td>
      <td>married</td>
      <td>unknown</td>
      <td>unknown</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>tue</td>
      <td>...</td>
      <td>1.1</td>
      <td>93.994</td>
      <td>-36.4</td>
      <td>4.857</td>
      <td>5191.0</td>
      <td>999.0</td>
      <td>0.0</td>
      <td>no</td>
      <td>NaN</td>
      <td>29.0</td>
    </tr>
    <tr>
      <th>29</th>
      <td>34.0</td>
      <td>technician</td>
      <td>single</td>
      <td>NaN</td>
      <td>no</td>
      <td>yes</td>
      <td>no</td>
      <td>telephone</td>
      <td>may</td>
      <td>NaN</td>
      <td>...</td>
      <td>-1.8</td>
      <td>92.893</td>
      <td>-46.2</td>
      <td>1.334</td>
      <td>5099.1</td>
      <td>999.0</td>
      <td>0.0</td>
      <td>no</td>
      <td>NaN</td>
      <td>30.0</td>
    </tr>
  </tbody>
</table>
<p>30 rows × 24 columns</p>
</div>




```python
# Datatypes of the columns
train.dtypes
```




    custAge           float64
    profession         object
    marital            object
    schooling          object
    default            object
    housing            object
    loan               object
    contact            object
    month              object
    day_of_week        object
    campaign          float64
    pdays             float64
    previous          float64
    poutcome           object
    emp.var.rate      float64
    cons.price.idx    float64
    cons.conf.idx     float64
    euribor3m         float64
    nr.employed       float64
    pmonths           float64
    pastEmail         float64
    responded          object
    profit            float64
    id                float64
    dtype: object




```python
# checkout the duplicate rows
duplicate = train[train.duplicated()]
print("Duplicate Rows :") 
duplicate
```

    Duplicate Rows :
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>custAge</th>
      <th>profession</th>
      <th>marital</th>
      <th>schooling</th>
      <th>default</th>
      <th>housing</th>
      <th>loan</th>
      <th>contact</th>
      <th>month</th>
      <th>day_of_week</th>
      <th>...</th>
      <th>emp.var.rate</th>
      <th>cons.price.idx</th>
      <th>cons.conf.idx</th>
      <th>euribor3m</th>
      <th>nr.employed</th>
      <th>pmonths</th>
      <th>pastEmail</th>
      <th>responded</th>
      <th>profit</th>
      <th>id</th>
    </tr>
  </thead>
  <tbody>
  </tbody>
</table>
<p>0 rows × 24 columns</p>
</div>




```python
train.drop_duplicates(inplace=True)
```


```python
train.groupby(['profession']).count().plot(kind='pie', y='responded',figsize = (10,11))
```




    <Axes: ylabel='responded'>




    
![png](output_8_1.png)
    



```python
# Group by 'profession' and count 'responded'
profession_counts = train.groupby('profession')['responded'].count()

# Sort the counts in descending order
profession_counts = profession_counts.sort_values(ascending=False)

# Calculate cumulative percentage
cumulative_percentage = profession_counts.cumsum() / profession_counts.sum() * 100

# Plot the Pareto chart
fig, ax = plt.subplots(figsize=(12, 6))  # Set figure size for better readability

# Bar chart (counts of 'responded')
ax.bar(profession_counts.index, profession_counts, color='blue')

# Line chart (cumulative percentage)
ax2 = ax.twinx()
ax2.plot(profession_counts.index, cumulative_percentage, color='red', marker='o')

# Rotate x-axis labels for readability
plt.xticks(rotation=45, ha='right')

# Labeling
ax.set_xlabel('Profession')
ax.set_ylabel('Count of Responded', color='blue')
ax2.set_ylabel('Cumulative Percentage (%)', color='red')
plt.title('Pareto Chart for Profession based on Responded')

# Adjust the layout to prevent label cutoff
plt.tight_layout()

# Display the chart
plt.show()

```


    
![png](output_9_0.png)
    


As we can see, majority of our potential customer comes from admin,blue-collar, technician workgroup. followed by services abd Management  
these 6 groups contributes to more than 80% of the potental customer


```python
import seaborn as sns
plt.figure(figsize=(15,15))
sns.pairplot(train[['campaign','pdays','previous','responded']],hue='responded')
plt.show()
```

    C:\Users\91638\anaconda3\Lib\site-packages\seaborn\axisgrid.py:118: UserWarning: The figure layout has changed to tight
      self._figure.tight_layout(*args, **kwargs)
    


    <Figure size 1500x1500 with 0 Axes>



    
![png](output_11_2.png)
    



```python
# Checking Null Values
train.isna().sum()/len(train)*100
```




    custAge           24.466019
    profession         0.024272
    marital            0.024272
    schooling         29.223301
    default            0.024272
    housing            0.024272
    loan               0.024272
    contact            0.024272
    month              0.024272
    day_of_week        9.575243
    campaign           0.024272
    pdays              0.024272
    previous           0.024272
    poutcome           0.024272
    emp.var.rate       0.024272
    cons.price.idx     0.024272
    cons.conf.idx      0.024272
    euribor3m          0.024272
    nr.employed        0.024272
    pmonths            0.024272
    pastEmail          0.024272
    responded          0.024272
    profit            88.713592
    id                 0.024272
    dtype: float64




```python
#lets find out the Average age of each proffession
mean_age_by_both = train.groupby(['profession','marital'])['custAge'].mean()
mean_age_by_both

# we can see the age group shows better variance when it is grouped on the
# basis of  profession and marital status
```




    profession     marital 
    admin.         divorced    43.558511
                   married     40.558322
                   single      32.895522
                   unknown     29.000000
    blue-collar    divorced    42.708333
                   married     40.506890
                   single      33.167857
                   unknown     45.000000
    entrepreneur   divorced    44.200000
                   married     42.901099
                   single      34.125000
    housemaid      divorced    52.040000
                   married     45.966667
                   single      40.153846
                   unknown     33.000000
    management     divorced    47.731707
                   married     43.591054
                   single      33.222222
    retired        divorced    63.500000
                   married     63.098901
                   single      56.388889
    self-employed  divorced    43.428571
                   married     43.562044
                   single      32.366667
    services       divorced    43.461538
                   married     40.297143
                   single      31.696203
                   unknown     33.000000
    student        divorced    33.000000
                   married     28.500000
                   single      25.921053
    technician     divorced    42.208696
                   married     40.170909
                   single      33.737143
    unemployed     divorced    42.052632
                   married     40.526882
                   single      34.176471
    unknown        divorced    59.500000
                   married     49.487179
                   single      34.900000
                   unknown     45.000000
    Name: custAge, dtype: float64




```python
# now lets fill the missing values of the custAge column with the mean

def fill_age(row):
    # Check if 'custAge' is missing
    if pd.isnull(row['custAge']):
        # Check if 'profession' or 'marital' is NaN
        if pd.isnull(row['profession']) or pd.isnull(row['marital']):
            return train['custAge'].mean()  # Fill with overall mean if either is NaN
        else:
            # Fill with the mean age for the corresponding profession + marital status
            return mean_age_by_both.get((row['profession'], row['marital']), train['custAge'].mean())  
    else:
        return row['custAge']  # If not missing, keep the original value

# Apply the function to fill missing 'custAge' values
train['custAge'] = train.apply(fill_age, axis=1)
```


```python
# Check if there are any remaining missing values in the Age column
train['custAge'].isnull().sum()/len(train)*100

```




    0.0




```python
# Group by 'profession' and calculate the mode of 'schooling'
mode_schooling_by_profession = train.groupby('profession')['schooling'].agg(lambda x: x.mode().iloc[0] if not x.mode().empty else None)

# Check the mode schooling for each profession (optional)
print(mode_schooling_by_profession)

```

    profession
    admin.             university.degree
    blue-collar                 basic.9y
    entrepreneur       university.degree
    housemaid                   basic.4y
    management         university.degree
    retired                     basic.4y
    self-employed      university.degree
    services                 high.school
    student                  high.school
    technician       professional.course
    unemployed               high.school
    unknown                      unknown
    Name: schooling, dtype: object
    


```python
# Define a function to fill missing 'schooling' values using the group-specific mode
def fill_schooling(row):
    if pd.isnull(row['schooling']):  # Check if 'schooling' is missing
        # Fill with the mode schooling for the corresponding profession
        return mode_schooling_by_profession.get(row['profession'], train['schooling'].mode().iloc[0])  
    else:
        return row['schooling']  # If not missing, return the original value

# Apply the function to fill missing 'schooling' values
train['schooling'] = train.apply(fill_schooling, axis=1)

```


```python
# Check for any remaining missing values in 'schooling'
print(train['schooling'].isnull().sum())
```

    0
    


```python
train.isna().sum()/len(train)*100
```




    custAge            0.000000
    profession         0.024272
    marital            0.024272
    schooling          0.000000
    default            0.024272
    housing            0.024272
    loan               0.024272
    contact            0.024272
    month              0.024272
    day_of_week        9.575243
    campaign           0.024272
    pdays              0.024272
    previous           0.024272
    poutcome           0.024272
    emp.var.rate       0.024272
    cons.price.idx     0.024272
    cons.conf.idx      0.024272
    euribor3m          0.024272
    nr.employed        0.024272
    pmonths            0.024272
    pastEmail          0.024272
    responded          0.024272
    profit            88.713592
    id                 0.024272
    dtype: float64




```python
# we can see that the column profit is having 88% missing values
# so lets drop that column
train.drop(columns=['profit'], inplace=True)
```


```python
train.isna().sum()
```




    custAge             0
    profession          2
    marital             2
    schooling           0
    default             2
    housing             2
    loan                2
    contact             2
    month               2
    day_of_week       789
    campaign            2
    pdays               2
    previous            2
    poutcome            2
    emp.var.rate        2
    cons.price.idx      2
    cons.conf.idx       2
    euribor3m           2
    nr.employed         2
    pmonths             2
    pastEmail           2
    responded           2
    id                  2
    dtype: int64




```python
# Check unique values and their frequency in 'day_of_week'
train.dropna(inplace=True)
```


```python
train.isna().sum()
```




    custAge           0
    profession        0
    marital           0
    schooling         0
    default           0
    housing           0
    loan              0
    contact           0
    month             0
    day_of_week       0
    campaign          0
    pdays             0
    previous          0
    poutcome          0
    emp.var.rate      0
    cons.price.idx    0
    cons.conf.idx     0
    euribor3m         0
    nr.employed       0
    pmonths           0
    pastEmail         0
    responded         0
    id                0
    dtype: int64




```python
len(train)
```




    7451



# Exploratory data analysis



```python
#Lets start with descriptive statistics
train.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>custAge</th>
      <th>campaign</th>
      <th>pdays</th>
      <th>previous</th>
      <th>emp.var.rate</th>
      <th>cons.price.idx</th>
      <th>cons.conf.idx</th>
      <th>euribor3m</th>
      <th>nr.employed</th>
      <th>pmonths</th>
      <th>pastEmail</th>
      <th>id</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>7451.000000</td>
      <td>7451.000000</td>
      <td>7451.000000</td>
      <td>7451.000000</td>
      <td>7451.000000</td>
      <td>7451.000000</td>
      <td>7451.000000</td>
      <td>7451.000000</td>
      <td>7451.000000</td>
      <td>7451.000000</td>
      <td>7451.000000</td>
      <td>7451.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>40.034952</td>
      <td>2.542209</td>
      <td>960.487183</td>
      <td>0.186015</td>
      <td>0.049886</td>
      <td>93.567055</td>
      <td>-40.572983</td>
      <td>3.580949</td>
      <td>5165.349805</td>
      <td>960.259885</td>
      <td>0.367199</td>
      <td>4108.526372</td>
    </tr>
    <tr>
      <th>std</th>
      <td>9.769468</td>
      <td>2.749337</td>
      <td>191.737081</td>
      <td>0.514251</td>
      <td>1.566450</td>
      <td>0.577189</td>
      <td>4.659837</td>
      <td>1.743512</td>
      <td>72.684651</td>
      <td>192.867165</td>
      <td>1.281638</td>
      <td>2376.241722</td>
    </tr>
    <tr>
      <th>min</th>
      <td>18.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>-3.400000</td>
      <td>92.201000</td>
      <td>-50.800000</td>
      <td>0.634000</td>
      <td>4963.600000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>33.000000</td>
      <td>1.000000</td>
      <td>999.000000</td>
      <td>0.000000</td>
      <td>-1.800000</td>
      <td>93.075000</td>
      <td>-42.700000</td>
      <td>1.334000</td>
      <td>5099.100000</td>
      <td>999.000000</td>
      <td>0.000000</td>
      <td>2056.500000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>40.000000</td>
      <td>2.000000</td>
      <td>999.000000</td>
      <td>0.000000</td>
      <td>1.100000</td>
      <td>93.444000</td>
      <td>-41.800000</td>
      <td>4.857000</td>
      <td>5191.000000</td>
      <td>999.000000</td>
      <td>0.000000</td>
      <td>4112.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>45.000000</td>
      <td>3.000000</td>
      <td>999.000000</td>
      <td>0.000000</td>
      <td>1.400000</td>
      <td>93.994000</td>
      <td>-36.400000</td>
      <td>4.961000</td>
      <td>5228.100000</td>
      <td>999.000000</td>
      <td>0.000000</td>
      <td>6156.500000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>94.000000</td>
      <td>40.000000</td>
      <td>999.000000</td>
      <td>5.000000</td>
      <td>1.400000</td>
      <td>94.767000</td>
      <td>-26.900000</td>
      <td>5.045000</td>
      <td>5228.100000</td>
      <td>999.000000</td>
      <td>25.000000</td>
      <td>8238.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
train.groupby(['profession']).count().plot(kind='pie', y='responded',figsize = (10,11))
```




    <Axes: ylabel='responded'>




    
![png](output_27_1.png)
    



```python
train.info()
```

    <class 'pandas.core.frame.DataFrame'>
    Index: 7451 entries, 0 to 8237
    Data columns (total 23 columns):
     #   Column          Non-Null Count  Dtype  
    ---  ------          --------------  -----  
     0   custAge         7451 non-null   float64
     1   profession      7451 non-null   object 
     2   marital         7451 non-null   object 
     3   schooling       7451 non-null   object 
     4   default         7451 non-null   object 
     5   housing         7451 non-null   object 
     6   loan            7451 non-null   object 
     7   contact         7451 non-null   object 
     8   month           7451 non-null   object 
     9   day_of_week     7451 non-null   object 
     10  campaign        7451 non-null   float64
     11  pdays           7451 non-null   float64
     12  previous        7451 non-null   float64
     13  poutcome        7451 non-null   object 
     14  emp.var.rate    7451 non-null   float64
     15  cons.price.idx  7451 non-null   float64
     16  cons.conf.idx   7451 non-null   float64
     17  euribor3m       7451 non-null   float64
     18  nr.employed     7451 non-null   float64
     19  pmonths         7451 non-null   float64
     20  pastEmail       7451 non-null   float64
     21  responded       7451 non-null   object 
     22  id              7451 non-null   float64
    dtypes: float64(12), object(11)
    memory usage: 1.4+ MB
    

# Encoding and feature scaling


```python
#seperating the numerical and categorical columns
from sklearn.preprocessing import StandardScaler
def data_type(train):
    numerical = []
    categorical = []
    for i in train.columns:
        if train[i].dtype == 'int64' or train[i].dtype=='float64':
            numerical.append(i)
        else:
            categorical.append(i)
    return numerical, categorical
numerical, categorical = data_type(train)

# Identifying the binary columns and ignoring them from scaling
def binary_columns(train):
    binary_cols = []
    for col in train.select_dtypes(include=['int', 'float']).columns:
        unique_values = train[col].unique()
        if np.in1d(unique_values, [0, 1]).all():
            binary_cols.append(col)
    return binary_cols

binary_cols = binary_columns(train)
```


```python
# Remove the binary columns from the numerical columns
numerical = [i for i in numerical if i not in binary_cols]

def encoding(train, categorical):
    for i in categorical:
        train[i] = train[i].astype('category')
        train[i] = train[i].cat.codes
    return train

train = encoding(train, categorical)
```


```python
def feature_scaling(train, numerical):
    sc_x = StandardScaler()
    train[numerical] = sc_x.fit_transform(train[numerical])
    return train

train = feature_scaling(train, numerical)
```


```python
train.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>custAge</th>
      <th>profession</th>
      <th>marital</th>
      <th>schooling</th>
      <th>default</th>
      <th>housing</th>
      <th>loan</th>
      <th>contact</th>
      <th>month</th>
      <th>day_of_week</th>
      <th>...</th>
      <th>poutcome</th>
      <th>emp.var.rate</th>
      <th>cons.price.idx</th>
      <th>cons.conf.idx</th>
      <th>euribor3m</th>
      <th>nr.employed</th>
      <th>pmonths</th>
      <th>pastEmail</th>
      <th>responded</th>
      <th>id</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>-0.617777</td>
      <td>0</td>
      <td>2</td>
      <td>6</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>4</td>
      <td>...</td>
      <td>1</td>
      <td>-1.181021</td>
      <td>-0.852560</td>
      <td>-1.400790</td>
      <td>-1.194766</td>
      <td>-0.911530</td>
      <td>0.200878</td>
      <td>-0.286527</td>
      <td>0</td>
      <td>-1.728697</td>
    </tr>
    <tr>
      <th>1</th>
      <td>-0.924877</td>
      <td>7</td>
      <td>2</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>2</td>
      <td>...</td>
      <td>1</td>
      <td>0.861952</td>
      <td>0.608065</td>
      <td>-0.456488</td>
      <td>0.795603</td>
      <td>0.863379</td>
      <td>0.200878</td>
      <td>-0.286527</td>
      <td>0</td>
      <td>-1.728276</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1.224821</td>
      <td>0</td>
      <td>0</td>
      <td>6</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>3</td>
      <td>...</td>
      <td>1</td>
      <td>0.861952</td>
      <td>0.608065</td>
      <td>-0.456488</td>
      <td>0.792162</td>
      <td>0.863379</td>
      <td>0.200878</td>
      <td>-0.286527</td>
      <td>0</td>
      <td>-1.727434</td>
    </tr>
    <tr>
      <th>4</th>
      <td>-0.105944</td>
      <td>1</td>
      <td>2</td>
      <td>2</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>3</td>
      <td>...</td>
      <td>1</td>
      <td>0.861952</td>
      <td>0.608065</td>
      <td>-0.456488</td>
      <td>0.791588</td>
      <td>0.863379</td>
      <td>0.200878</td>
      <td>-0.286527</td>
      <td>0</td>
      <td>-1.727014</td>
    </tr>
    <tr>
      <th>5</th>
      <td>-0.003578</td>
      <td>2</td>
      <td>1</td>
      <td>6</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>1</td>
      <td>4</td>
      <td>2</td>
      <td>...</td>
      <td>1</td>
      <td>0.861952</td>
      <td>1.555826</td>
      <td>-0.263335</td>
      <td>0.737097</td>
      <td>0.863379</td>
      <td>0.200878</td>
      <td>-0.286527</td>
      <td>0</td>
      <td>-1.726593</td>
    </tr>
    <tr>
      <th>6</th>
      <td>1.020088</td>
      <td>9</td>
      <td>2</td>
      <td>5</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>3</td>
      <td>...</td>
      <td>1</td>
      <td>0.861952</td>
      <td>0.608065</td>
      <td>-0.456488</td>
      <td>0.791588</td>
      <td>0.863379</td>
      <td>0.200878</td>
      <td>-0.286527</td>
      <td>0</td>
      <td>-1.726172</td>
    </tr>
    <tr>
      <th>7</th>
      <td>0.098789</td>
      <td>9</td>
      <td>1</td>
      <td>5</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>8</td>
      <td>2</td>
      <td>...</td>
      <td>1</td>
      <td>-2.202508</td>
      <td>-1.968388</td>
      <td>2.934416</td>
      <td>-1.628976</td>
      <td>-2.034263</td>
      <td>0.200878</td>
      <td>-0.286527</td>
      <td>0</td>
      <td>-1.725751</td>
    </tr>
    <tr>
      <th>8</th>
      <td>-1.743810</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>1</td>
      <td>4</td>
      <td>0</td>
      <td>...</td>
      <td>1</td>
      <td>0.861952</td>
      <td>1.555826</td>
      <td>-0.263335</td>
      <td>0.790441</td>
      <td>0.863379</td>
      <td>0.200878</td>
      <td>-0.286527</td>
      <td>0</td>
      <td>-1.725330</td>
    </tr>
    <tr>
      <th>9</th>
      <td>-1.129610</td>
      <td>9</td>
      <td>1</td>
      <td>5</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>...</td>
      <td>1</td>
      <td>0.861952</td>
      <td>-0.213212</td>
      <td>0.959966</td>
      <td>0.793882</td>
      <td>0.863379</td>
      <td>0.200878</td>
      <td>-0.286527</td>
      <td>0</td>
      <td>-1.724909</td>
    </tr>
    <tr>
      <th>11</th>
      <td>-0.720144</td>
      <td>1</td>
      <td>1</td>
      <td>7</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>1</td>
      <td>...</td>
      <td>1</td>
      <td>0.861952</td>
      <td>0.608065</td>
      <td>-0.456488</td>
      <td>0.791014</td>
      <td>0.863379</td>
      <td>0.200878</td>
      <td>-0.286527</td>
      <td>0</td>
      <td>-1.724068</td>
    </tr>
  </tbody>
</table>
<p>10 rows × 23 columns</p>
</div>




```python
# now we can see that the 
```


```python
X = train.drop(columns=['responded'])
y = train['responded']
X_train,X_test,y_train,y_test = train_test_split(X, y, test_size = 0.2, random_state=42)
```

# logistic Regression Model


```python
# 1. Logistic Regression
from sklearn.linear_model import LogisticRegression
logmodel = LogisticRegression(solver='liblinear', max_iter=200)
logmodel.fit(X_train, y_train)
log_pred = logmodel.predict(X_test)
log_acc = accuracy_score(y_test, log_pred)
log_cm = confusion_matrix(y_test, log_pred)
print(f'Logistic Regression Accuracy: {log_acc}')
print(f'Logistic Regression Confusion Matrix:\n{log_cm}')
```

    Logistic Regression Accuracy: 0.98859825620389
    Logistic Regression Confusion Matrix:
    [[1316    9]
     [   8  158]]
    


```python
# 2. Decision Tree Classifier
from sklearn.tree import DecisionTreeClassifier
dt_model = DecisionTreeClassifier()
dt_model.fit(X_train, y_train)
dt_pred = dt_model.predict(X_test)
dt_acc = accuracy_score(y_test, dt_pred)
dt_cm = confusion_matrix(y_test, dt_pred)
print(f'Decision Tree Accuracy: {dt_acc}')
print(f'Decision Tree Confusion Matrix:\n{dt_cm}')
```

    Decision Tree Accuracy: 1.0
    Decision Tree Confusion Matrix:
    [[1325    0]
     [   0  166]]
    


```python

# 3. Random Forest Classifier
from sklearn.ensemble import RandomForestClassifier
rf_model = RandomForestClassifier(n_estimators=100)
rf_model.fit(X_train, y_train)
rf_pred = rf_model.predict(X_test)
rf_acc = accuracy_score(y_test, rf_pred)
rf_cm = confusion_matrix(y_test, rf_pred)
print(f'Random Forest Accuracy: {rf_acc}')
print(f'Random Forest Confusion Matrix:\n{rf_cm}')
```

    Random Forest Accuracy: 1.0
    Random Forest Confusion Matrix:
    [[1325    0]
     [   0  166]]
    


```python
# 4. Gradient Boosting Classifier
from sklearn.ensemble import GradientBoostingClassifier
gb_model = GradientBoostingClassifier()
gb_model.fit(X_train, y_train)
gb_pred = gb_model.predict(X_test)
gb_acc = accuracy_score(y_test, gb_pred)
gb_cm = confusion_matrix(y_test, gb_pred)
print(f'Gradient Boosting Accuracy: {gb_acc}')
print(f'Gradient Boosting Confusion Matrix:\n{gb_cm}')
```

    Gradient Boosting Accuracy: 1.0
    Gradient Boosting Confusion Matrix:
    [[1325    0]
     [   0  166]]
    


```python
# 5. Support Vector Machine (SVM)
from sklearn.svm import SVC
svm_model = SVC()
svm_model.fit(X_train, y_train)
svm_pred = svm_model.predict(X_test)
svm_acc = accuracy_score(y_test, svm_pred)
svm_cm = confusion_matrix(y_test, svm_pred)
print(f'SVM Accuracy: {svm_acc}')
print(f'SVM Confusion Matrix:\n{svm_cm}')
```

    SVM Accuracy: 0.9590878604963112
    SVM Confusion Matrix:
    [[1308   17]
     [  44  122]]
    


```python
# 6. Naive Bayes Classifier
from sklearn.naive_bayes import GaussianNB
nb_model = GaussianNB()
nb_model.fit(X_train, y_train)
nb_pred = nb_model.predict(X_test)
nb_acc = accuracy_score(y_test, nb_pred)
nb_cm = confusion_matrix(y_test, nb_pred)
print(f'Naive Bayes Accuracy: {nb_acc}')
print(f'Naive Bayes Confusion Matrix:\n{nb_cm}')
```

    Naive Bayes Accuracy: 0.95439302481556
    Naive Bayes Confusion Matrix:
    [[1307   18]
     [  50  116]]
    

The evaluation of various classification models revealed that tree-based methods, such as Decision Tree, Random Forest, and Gradient Boosting, achieved perfect accuracy (100%) on the test set, which may indicate overfitting. Logistic Regression also performed strongly with an accuracy of 98.86%, effectively identifying candidates to market. In contrast, Support Vector Machine and Naive Bayes classifiers had lower accuracies of 95.91% and 95.44%, respectively, demonstrating higher false negatives.


```python
# Load the unseen data
unseen_data = pd.read_excel('test.xlsx')
```


```python
print(unseen_data.isnull().sum())
```

    custAge           8042
    profession           0
    marital              0
    schooling            0
    default              0
    housing              0
    loan                 0
    contact              0
    month                0
    day_of_week          0
    campaign             0
    pdays                0
    previous             0
    poutcome             0
    emp.var.rate         0
    cons.price.idx       0
    cons.conf.idx        0
    euribor3m            0
    nr.employed          0
    pmonths              0
    pastEmail            0
    id                   0
    dtype: int64
    


```python
unseen_data.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 32950 entries, 0 to 32949
    Data columns (total 22 columns):
     #   Column          Non-Null Count  Dtype  
    ---  ------          --------------  -----  
     0   custAge         24908 non-null  float64
     1   profession      32950 non-null  object 
     2   marital         32950 non-null  object 
     3   schooling       23180 non-null  object 
     4   default         32950 non-null  object 
     5   housing         32950 non-null  object 
     6   loan            32950 non-null  object 
     7   contact         32950 non-null  object 
     8   month           32950 non-null  object 
     9   day_of_week     29622 non-null  object 
     10  campaign        32950 non-null  int64  
     11  pdays           32950 non-null  int64  
     12  previous        32950 non-null  int64  
     13  poutcome        32950 non-null  object 
     14  emp.var.rate    32950 non-null  float64
     15  cons.price.idx  32950 non-null  float64
     16  cons.conf.idx   32950 non-null  float64
     17  euribor3m       32950 non-null  float64
     18  nr.employed     32950 non-null  float64
     19  pmonths         32950 non-null  float64
     20  pastEmail       32950 non-null  int64  
     21  id              32950 non-null  int64  
    dtypes: float64(7), int64(5), object(10)
    memory usage: 5.5+ MB
    


```python
# Calculate mean age grouped by profession and marital status for unseen data
mean_age_by_both_unseen = unseen_data.groupby(['profession', 'marital'])['custAge'].mean()

# Function to fill missing 'custAge' values in unseen_data
def fill_age_unseen(row):
    # Check if 'custAge' is missing
    if pd.isnull(row['custAge']):
        # Check if 'profession' or 'marital' is NaN
        if pd.isnull(row['profession']) or pd.isnull(row['marital']):
            return train['custAge'].mean()  # Fill with overall mean if either is NaN
        else:
            # Fill with the mean age for the corresponding profession + marital status
            return mean_age_by_both_unseen.get((row['profession'], row['marital']), train['custAge'].mean())
    else:
        return row['custAge']  # If not missing, keep the original value

# Apply the function to fill missing 'custAge' values in unseen_data
unseen_data['custAge'] = unseen_data.apply(fill_age_unseen, axis=1)

```


```python
# Function to separate numerical and categorical columns
def data_type(unseen_data):
    numerical = []
    categorical = []
    for column in unseen_data.columns:
        if unseen_data[column].dtype == 'int64' or unseen_data[column].dtype == 'float64':
            numerical.append(column)
        else:
            categorical.append(column)
    return numerical, categorical

# Identify binary columns
def binary_columns(unseen_data):
    binary_cols = []
    for column in unseen_data.select_dtypes(include=['int', 'float']).columns:
        unique_values = unseen_data[column].unique()
        if np.in1d(unique_values, [0, 1]).all():
            binary_cols.append(column)
    return binary_cols

# Get numerical and categorical columns
numerical_unseen, categorical_unseen = data_type(unseen_data)

# Identify binary columns and remove them from numerical columns
binary_cols_unseen = binary_columns(unseen_data)
numerical_unseen = [col for col in numerical_unseen if col not in binary_cols_unseen]

# Function to encode categorical variables
def encoding(unseen_data, categorical):
    for column in categorical:
        unseen_data[column] = unseen_data[column].astype('category')
        unseen_data[column] = unseen_data[column].cat.codes
    return unseen_data

# Encode categorical variables in the unseen data
unseen_data = encoding(unseen_data, categorical_unseen)

# Feature scaling for numerical columns
def feature_scaling(unseen_data, numerical):
    sc_x = StandardScaler()
    unseen_data[numerical] = sc_x.fit_transform(unseen_data[numerical])
    return unseen_data

# Scale numerical columns in the unseen data
unseen_data = feature_scaling(unseen_data, numerical_unseen)

```


```python
import joblib

joblib.dump(rf_model, 'random_forest_model.pkl')
```




    ['random_forest_model.pkl']




```python
model = joblib.load('random_forest_model.pkl')  
# Make predictions
predictions = model.predict(unseen_data)

# Add predictions to the unseen data DataFrame
unseen_data['predicted_market'] = predictions

# Save the updated unseen data with predictions to the same file
unseen_data.to_excel('test_with_predictions.xlsx', index=False)
```


```python

```


```python

```
